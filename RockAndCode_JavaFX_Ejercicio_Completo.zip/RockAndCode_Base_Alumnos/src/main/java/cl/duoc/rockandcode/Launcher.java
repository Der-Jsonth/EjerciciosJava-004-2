package cl.duoc.rockandcode;

/** Punto de entrada alternativo para ejecutar desde un IDE. */
public class Launcher {
    public static void main(String[] args) {
        App.main(args);
    }
}
