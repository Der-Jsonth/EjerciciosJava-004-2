package cl.duoc.rockandcode.controller;

import javafx.fxml.FXML;

/**
 * ACTIVIDAD: implementar el controlador del formulario.
 * 1. Declarar campos @FXML cuyos fx:id coincidan con el archivo FXML.
 * 2. Configurar el ComboBox en initialize().
 * 3. Vincular el botón Guardar álbum con #guardarAlbum en el FXML.
 * 4. Validar String, int, double, ComboBox y CheckBox.
 * 5. Mostrar un mensaje de error o éxito en un Label.
 * 6. Limpiar solo después de un registro válido.
 * No crear DAO, Repository ni persistencia.
 */
public class AlbumController {

    @FXML
    private void initialize() {
        // TODO: configurar las opciones Rock, Metal, Pop, Jazz y Otro.
    }

    @FXML
    private void guardarAlbum() {
        // TODO: leer, convertir, validar, simular y limpiar.
    }
}
