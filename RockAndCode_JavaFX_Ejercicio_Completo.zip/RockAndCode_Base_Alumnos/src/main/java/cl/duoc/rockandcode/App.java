package cl.duoc.rockandcode;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class App extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(App.class.getResource("/cl/duoc/rockandcode/main-view.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setTitle("Rock & Code - Registro de álbumes");
        stage.setScene(scene);
        stage.setMinWidth(690);
        stage.setMinHeight(650);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
