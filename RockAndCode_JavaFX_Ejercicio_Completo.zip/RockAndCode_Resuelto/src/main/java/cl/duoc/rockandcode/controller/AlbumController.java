package cl.duoc.rockandcode.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class AlbumController {

    @FXML private TextField txtArtista;
    @FXML private TextField txtAlbum;
    @FXML private TextField txtAnio;
    @FXML private TextField txtDuracion;
    @FXML private ComboBox<String> cmbGenero;
    @FXML private CheckBox chkEdicionEspecial;
    @FXML private Label lblMensaje;

    @FXML
    private void initialize() {
        cmbGenero.setItems(FXCollections.observableArrayList(
                "Rock", "Metal", "Pop", "Jazz", "Otro"));
        cmbGenero.getSelectionModel().clearSelection();
        chkEdicionEspecial.setSelected(false);
        lblMensaje.setText("Completa los campos para registrar un álbum.");
    }

    @FXML
    private void guardarAlbum() {
        String artista = txtArtista.getText().trim();
        String album = txtAlbum.getText().trim();

        if (artista.length() < 2) {
            mostrarError("El nombre de la banda o artista debe tener al menos 2 caracteres.");
            return;
        }
        if (album.length() < 2) {
            mostrarError("El nombre del álbum debe tener al menos 2 caracteres.");
            return;
        }

        int anio;
        try {
            anio = Integer.parseInt(txtAnio.getText().trim());
        } catch (NumberFormatException ex) {
            mostrarError("El año de lanzamiento debe ser un número entero.");
            return;
        }
        if (anio < 1950 || anio > 2026) {
            mostrarError("El año debe estar entre 1950 y 2026.");
            return;
        }

        double duracion;
        try {
            duracion = Double.parseDouble(txtDuracion.getText().trim());
        } catch (NumberFormatException ex) {
            mostrarError("La duración debe ser un número válido (utiliza punto decimal).");
            return;
        }
        if (!Double.isFinite(duracion) || duracion <= 0 || duracion > 300) {
            mostrarError("La duración debe ser mayor que 0 y menor o igual a 300 minutos.");
            return;
        }

        String genero = cmbGenero.getValue();
        if (genero == null || genero.isBlank()) {
            mostrarError("Debe seleccionar un género musical.");
            return;
        }

        boolean esEspecial = chkEdicionEspecial.isSelected();
        mostrarExito("Álbum '" + album + "' de " + artista
                + " guardado correctamente. Género: " + genero
                + ". Edición especial: " + (esEspecial ? "Sí" : "No") + ".");
        limpiarFormulario();
        // No se guardan datos en listas, archivos ni bases de datos.
    }

    private void mostrarError(String mensaje) {
        lblMensaje.getStyleClass().removeAll("mensaje-exito", "mensaje-info");
        if (!lblMensaje.getStyleClass().contains("mensaje-error")) {
            lblMensaje.getStyleClass().add("mensaje-error");
        }
        lblMensaje.setText(mensaje);
    }

    private void mostrarExito(String mensaje) {
        lblMensaje.getStyleClass().removeAll("mensaje-error", "mensaje-info");
        if (!lblMensaje.getStyleClass().contains("mensaje-exito")) {
            lblMensaje.getStyleClass().add("mensaje-exito");
        }
        lblMensaje.setText(mensaje);
    }

    private void limpiarFormulario() {
        txtArtista.clear();
        txtAlbum.clear();
        txtAnio.clear();
        txtDuracion.clear();
        cmbGenero.getSelectionModel().clearSelection();
        chkEdicionEspecial.setSelected(false);
    }
}
